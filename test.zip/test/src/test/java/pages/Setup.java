package pages;

import io.github.bonigarcia.wdm.ChromeDriverManager;
import io.github.bonigarcia.wdm.FirefoxDriverManager;
import io.github.bonigarcia.wdm.InternetExplorerDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import java.util.concurrent.TimeUnit;

import static com.sun.xml.internal.ws.policy.sourcemodel.wspolicy.XmlToken.Optional;

/**
 * Created by SANYA on 5/20/2017.
 */
public class Setup {

    private static final String BROWSER_FIREFOX = "firefox";
    private static final String BROWSER_IE = "ie";
    private static final String BROWSER_CHROME = "chrome";
    public static final String PROTOCOL_PREFIX = "https://";
    public static final int TIMEOUT_VALUE = 10;

    //CrossBrowser testing method
    @Parameters({"browser"})
    public static WebDriver CrossBrows(@Optional("chrome") String browser, String address, String environment) {

        WebDriver driver = null;
        if (browser.equals(BROWSER_FIREFOX)) {
            FirefoxDriverManager.getInstance().setup();
            // System.setProperty("webdriver.gecko.driver", "C:\\Users\\SANYA\\Downloads\\geckodriver.exe");
            driver = new FirefoxDriver();

        } else if (browser.equals(BROWSER_CHROME)) {
            ChromeDriverManager.getInstance().setup();
            driver = new ChromeDriver();

        } else if (browser.equals(BROWSER_IE)) {
            InternetExplorerDriverManager.getInstance().setup();
            driver = new InternetExplorerDriver();

            // Some other browser instantiation

        } else {// Some other browser instantiation

        }
        driver.get(PROTOCOL_PREFIX + environment + address);
        driver.manage().window().maximize();
        driver.manage().timeouts().implicitlyWait(TIMEOUT_VALUE, TimeUnit.SECONDS);
        return driver;
    }

}
