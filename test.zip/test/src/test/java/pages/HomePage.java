package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Reporter;

import static org.testng.AssertJUnit.assertEquals;

/**
 * Created by SANYA on 5/20/2017.
 */
public class HomePage {

    private static final String expectedTitle = "automation";
    private static final String searchRequest = "automation";

    private WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    /**
     * This method performs fullfil search field by request and clicks "Search" button.
     */
    public void doSearchAutomation(){
        By searchfield = By.name("q");
        By searchButton = By.id("_fZl");
        driver.findElement(searchfield).sendKeys(searchRequest);
        Reporter.log("Fill search field", true);
        driver.findElement(searchButton).click();
        Reporter.log("Click search button", true);
    }

    /**
     * Opens first link and verify if page Title contains search request.
     */
    public void openLinkAssert(){
        By firstLink = By.id("vs0p1c0");
        driver.findElement(firstLink).click();
        Reporter.log("Open first Link", true);
        String actualTitle = driver.getTitle();
        Reporter.log("Get title to verify", true);
        assertEquals(expectedTitle, actualTitle.toLowerCase());

    }

    /**
     * Verifies if expected domain is displayed in search results on pages from 1 to 5.
     * @param domain
     * @return true if       othewise false.
     */
    public boolean expectDomain(String domain){
        //
        for (int i = 2; i < 6; i++) {
            Reporter.log("Search domain on page "+ i, true);
            if (driver.getPageSource().contains(domain)) {
                System.out.println("Link on page " + i);
                return true;
            } else {
                System.out.println("Text is absent on page " + i);
                driver.findElement(By.cssSelector("#pnnext>span")).click();
                Reporter.log("Click next button", true);
                try {
                    Thread.sleep(1000);
                } catch (InterruptedException exc) {
                    exc.printStackTrace();
                }
            }
        }
        return false;
    }
}

