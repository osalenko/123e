package task;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import pages.Setup;
import pages.HomePage;

/**
 * Created by SANYA on 5/20/2017.
 */
@Listeners(listener.Listener.class)
public class TestCases {

    private WebDriver driver;

    public HomePage homepage;

    @BeforeMethod(alwaysRun = true)
    public void before()

    {
        // Setup for BROWSER, ADDRESS(domain) and ENVIRONMENT which used for this test run
        driver = Setup.CrossBrows("chrome", "www.google.com", "");
    }

    @AfterMethod(alwaysRun = true)
    public void after() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void searchAutomation() {
        // open google.com
        homepage = new HomePage(driver);
        // search for "automation" request
        homepage.doSearchAutomation();
        // open first link and verify if Title as EXPECTED
        homepage.openLinkAssert();
    }

    @Test
    public void searchDomain() {
        // open google.com
        homepage = new HomePage(driver);
        // search for "automation" request
        homepage.doSearchAutomation();
        // verify if "testautomationday.com" present ir result on pages from 1 to 5
        assert (homepage.expectDomain("testautomationday.com"));
    }

}

